# Counts the number of occurences of triangular faces in the given topology file.
# Those faces which appear only once must lie on the surface. Surface faces are output
# to the specified surface file (preferred naming convention is "*.surf")
# pyrar@leeds.ac.uk

import sys

# First checks if the given face already exists. If so,
# it increments the counter for that face by 1. Otherwise,
# a new face is appended to the list with its counter set
# to 1.
def add_face(fl, n1, n2, n3, element):
	for f in fl:
		if n1 == f[0] and n2 == f[1] and n3 == f[2]:
			f[3] += 1
			return
	fl.append([n1, n2, n3, 1, element])
	return


if len(sys.argv) != 3:
	sys.exit("Usage: python extract_surface_from_topology.py [INPUT TOPOLOGY FILE] [OUTPUT SURFACE FILE]")

topfile = open(sys.argv[1], "r")

# get number of elements listed in topology file
num_elem = int(topfile.readline())

# create an empty list to which the faces can be added
face_list = []

# Get the node numbers for each element and use these
# to construct the element's 4 faces. Order each face so
# that the node indices appear in ascending order (to
# make it easier to quickly check if two faces are the same)
print "Counting occurrences of each face..."
for i in range(num_elem):
	line = topfile.readline()
	a = line.split()
	a[0] = int(a[0])
	a[1] = int(a[1])
	a[2] = int(a[2])
	a[3] = int(a[3])
	a.sort()
	add_face(face_list, a[0], a[1], a[2], i)
	add_face(face_list, a[0], a[1], a[3], i)
	add_face(face_list, a[0], a[2], a[3], i)
	add_face(face_list, a[1], a[2], a[3], i)
topfile.close()
print "done."

print "Culling duplicates..."
for i in range(len(face_list)-1, -1, -1):
	face = face_list[i]
	if face[3] != 1:
		face_list.remove(face)
print "done."

print "Writing surface faces to file..."
surffile = open(sys.argv[2], "w")
surffile.write(str(len(face_list)) + '\n')
for face in face_list:
	surffile.write(str(face[4]) + ' ' + str(face[0]) + ' ' + str(face[1]) + ' ' + str(face[2]) + '\n')
surffile.close()
print "done."
