arg_list = argv;
if nargin != 6
	printf("Usage: octave analyse_centroid_moment_evolution.m [INPUT FFEA centroid evolution fname] [num_moments] [timestep] [frame_length] [effective_radius] [viscosity]");
	exit(0);
endif

infname = arg_list{1};
out_basename = strsplit(infname, "/"){end};
timestep = str2double(arg_list{3});
frame_length = str2double(arg_list{4});
num_moments = str2num(arg_list{2});
radius = str2double(arg_list{5});
viscosity = str2double(arg_list{6});
D = 4.11e-21 / (6 * 3.1415 * viscosity * radius);

M = dlmread(infname);
M = M(4:end,1:num_moments * 4 + 1);

frame = M(:,1);
time = frame .* (frame_length * timestep);
for i = 1:num_moments;
	plot(time, M(:, 4 * (i - 1) + 2))
	xlabel("Time")
	ylabel(strcat("x^", num2str(i)))
	title(strcat("x Moment ", num2str(i), " evolution"))
	if i == 2
		hold on;
		expected = ones(rows(time), 1);
		expected = expected .* time;
		expected = expected .* (2 * D);
		plot(time, expected)
		hold off;
	endif
	print(strcat("moment_", num2str(i), "_x_", out_basename,".jpg"))
	
	plot(time, M(:, 4 * (i - 1) + 3))
	xlabel("Time")
	ylabel(strcat("y^", num2str(i)))
	title(strcat("y Moment ", num2str(i), " evolution"))
	if i == 2
		hold on;
		expected = ones(rows(time), 1);
		expected = expected .* time;
		expected = expected .* (2 * D);
		plot(time, expected)
		hold off;
	endif
	print(strcat("moment_", num2str(i), "_y_", out_basename,".jpg"))
	
	plot(time, M(:, 4 * (i - 1) + 4))
	xlabel("Time")
	ylabel(strcat("z^", num2str(i)))
	title(strcat("z Moment ", num2str(i), " evolution"))
	if i == 2
		hold on;
		expected = ones(rows(time), 1);
		expected = expected .* time;
		expected = expected .* (2 * D);
		plot(time, expected)
		hold off;
	endif
	print(strcat("moment_", num2str(i), "_z_", out_basename,".jpg"))

	plot(time, M(:, 4 * (i - 1) + 5))
	xlabel("Time")
	ylabel(strcat("r^", num2str(i)))
	title(strcat("r Moment ", num2str(i), " evolution"))
	if i == 2
		hold on;
		expected = ones(rows(time), 1);
		expected = expected .* time;
		expected = expected .* (6 * D);
		plot(time, expected)
		hold off;
	endif
	print(strcat("moment_", num2str(i), "_r_", out_basename,".jpg"))
endfor

