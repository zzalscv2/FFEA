arg_list = argv;
if nargin != 2
	printf("Usage: octave analyse_measurements.m [INPUT FFEA measurements fname] [num_nodes]");
	exit(0);
endif

infname = arg_list{1};
out_basename = strsplit(infname, "/"){end};
num_nodes = str2num(arg_list{2});

M = dlmread(infname);
M = M(2:end,:);

step = M(:,1);
ke = M(:,2);
pe = M(:,3);
comx = M(:,4);
comy = M(:,5);
comz = M(:,6);
lx = M(:,7);
ly = M(:,8);
lz = M(:,9);
rmsd = M(:,10);
vdw_a = M(:,11);
vdw_s = M(:,12);
vdw_e = M(:,13);

theoretical_ke = 3.0 * 4.11e-21 * num_nodes/2.0;
theory_ke_vec = ones(rows(step), 1);
theory_ke_vec = theory_ke_vec .* theoretical_ke;

theoretical_pe = 3.0 * 4.11e-21 * (num_nodes - 6)/2.0;
theory_pe_vec = ones(rows(step), 1);
theory_pe_vec = theory_pe_vec .* theoretical_pe;

plot(step, ke);
hold on;
plot(step, theory_ke_vec)
axis([0, step(end), 0, 3 * theoretical_ke])
xlabel("Frame");
ylabel("Kinetic Energy (J)");
title("Kinetic Energy Evolution")
print(strcat("ke_", out_basename,".jpg"));
hold off;

plot(step, pe);
hold on;
plot(step, theory_pe_vec)
axis([0, step(end), 0, 3 * theoretical_pe])
xlabel("Frame");
ylabel("Potential Energy (J)");
title("Potential Energy Evolution")
print(strcat("pe_", out_basename,".jpg"));
hold off;
