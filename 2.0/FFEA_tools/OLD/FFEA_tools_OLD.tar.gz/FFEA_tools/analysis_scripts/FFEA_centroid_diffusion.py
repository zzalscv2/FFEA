import sys, os
from math import *
import Vectors
import FFEA_traj

if len(sys.argv) != 2:
	sys.exit("Usage: python " + sys.argv[0]  + " [INPUT FFEA_trajectory file]")

base, ext = os.path.splitext(sys.argv[1])
traj=FFEA_traj.FFEA_traj(sys.argv[1], 10000)
traj.calc_centroid_moment_evolution(2, base + ".moments")
