#include <cstring>
#include <cstdlib>
#include <stdio.h>
#include <math.h>
#include "math_containers.h"

using namespace std;

// A volume class. In this case, simply a list of nodes and a num_nodes variable
class Volume {
	
	public:
		
		Volume(int num_nodes) {
			this->num_nodes = num_nodes;
			node = new vector3[num_nodes];
			centroid.set_pos(0.0, 0.0, 0.0);
		}
		
		~Volume() {
			num_nodes = 0;
			delete[] node;
			node = NULL;
			centroid.set_pos(0.0, 0.0, 0.0);
		}
		
		// Methods
		void translate(vector3 trans) {
			for(int i = 0; i < num_nodes; ++i) {
				node[i] += trans;
			}
		}
		
		void calc_centroid() {
			centroid.set_pos(0.0, 0.0, 0.0);
			for(int i = 0; i < num_nodes; ++i) {
				centroid += node[i];
			}
			centroid *= 1.0/num_nodes;
		}
		
		void rotate(matrix33 *a) {
			int i;
			for(i = 0; i < num_nodes; ++i) {
				a->apply(&node[i]);
			}
			return;
		}
		
		// Variables
		vector3 *node, centroid;
		int num_nodes;
};

// Global function to read a volume in from a .vol file. We only need the node data
Volume* read_vol_from_file(char *fname) {
	
	int i, num_nodes;
	Volume *volume;
	double x, y, z;
	char buf[100], line[6];
	FILE *vol_file;
	vol_file = fopen(fname, "r");
	while(!feof(vol_file)) {
		fgets(buf, sizeof(buf), vol_file);
		sscanf(buf, "%6s %*[^\n]", line);
		if(strcmp(line, "points") == 0) {
			break;
		}
	}
	fscanf(vol_file, "%d\n", &num_nodes);
	volume = new Volume(num_nodes);
	for(i = 0; i < num_nodes; ++i) {
		fscanf(vol_file, "%lf %lf %lf\n", &volume->node[i].x, &volume->node[i].y, &volume->node[i].z);
	}
	fclose(vol_file);
	return volume;	
}

// Function to calculate a map from vol to ref vol
int **calc_map(Volume *vol, Volume *ref_vol, int num_closest_nodes, double threshold) {
	int **map;
	int i, j, k;
	vector3 distance;
	
	map = new int*[vol->num_nodes];
	for(i = 0; i < vol->num_nodes; ++i) {
		map[i] = new int[num_closest_nodes];
		for(j = 0; j < ref_vol->num_nodes; ++j) {
			distance = vol->node[i] - ref_vol->node[j];
			distance.calc_mag();
			if(distance.mag < threshold) {
				map[i][k] = j;
				k++;
				if(k == num_closest_nodes) {
					k = 0;
					break;
				}
			}
		}
	}
	return map;	
}

// Write map to correct output format
void write_map_to_file(char *fname, int **map, int num_nodes_from, int num_closest_nodes) {
	FILE *fout;
	int i, j;
	fout = fopen(fname, "w");
	fprintf(fout, "FFEA Structure Mapping File\nnum_closest_nodes %d\nMap:\n", num_closest_nodes);
	for(i = 0; i < num_nodes_from; ++i) {
		for(j = 0; j < num_closest_nodes; ++j) {
			fprintf(fout, "%f ", map[i][j]);
		}
		fprintf(fout, "\n");
	}
	fclose(fout);
}

// Begin main program
int main(int argc, char **argv) {
	
	// Check correct variables
	if(argc != 11 and argc != 2) {
		printf("Usage: %s [INPUT reference .vol] [INPUT moving .vol] [OUTPUT .map] [Reference vol control node 1] [Moving vol control node 1] [Reference vol control node 2] [Moving vol control node 2] [Reference vol control node 3] [Moving vol control node 3] [num_closest_nodes for map]\n", argv[0]);
		return -1;
	}
	
	if(strcmp(argv[1], "-h") == 0) {
		printf("%s maps a volume onto a reference volume by translating the volume onto the reference volume\n", argv[0]);
		printf("and then creating a node-node map based upon the n closest nodes in the reference volume.\n\n");
		printf("Usage: %s [INPUT reference .vol] [INPUT moving .vol] [OUTPUT .map] [Reference vol control node 1] [Moving vol control node 1] [Reference vol control node 2] [Moving vol control node 2] [Reference vol control node 3] [Moving vol control node 3]\n", argv[0]);
		return -1;
	}
	
	// Read variables in
	printf("Reading arguments...");
	char *ref_vol_fname = argv[1];
	char *vol_fname = argv[2];
	char *output_fname = argv[3];
	int ref_control[3], control[3];
	ref_control[0] = atoi(argv[4]);
	control[0] = atoi(argv[5]);
	ref_control[1] = atoi(argv[6]);
	control[1] = atoi(argv[7]);
	ref_control[2] = atoi(argv[8]);
	control[2] = atoi(argv[9]);
	int num_closest_nodes = atoi(argv[10]);
	printf("done!\n");
	
	// Import the two volumes.
	printf("Reading volume data...");
	Volume *vol, *ref_vol;
	if((vol = read_vol_from_file(vol_fname)) == NULL) {
		printf("Error reading volume from %s\n", vol_fname);
		return -1;
	}
	if((ref_vol = read_vol_from_file(ref_vol_fname)) == NULL) {
		printf("Error reading volume from %s\n", ref_vol_fname);
		return -1;
	}
	printf("done!\n");
	
	// Translate control[0] to ref_control[0], then to origin
	printf("Moving control[0] onto ref_control[0]...");
	vector3 translation;
	translation = ref_vol->node[ref_control[0]] - vol->node[control[0]];
	
	// Translate 
	vol->translate(translation);
	
	// Move both to origin for rotation
	translation.set_pos(0.0, 0.0, 0.0);
	translation -= ref_vol->node[ref_control[0]];
	vol->translate(translation);
	ref_vol->translate(translation);
	printf("done!\n");
	
	// Calculate a rotation axis by using node[control[1]] - node[control[0]]
	printf("Minimising rmsd of control[0] and control[1]...");
	vector3 ref_control_to_control, control_to_control, rotation_axis;
	ref_control_to_control = ref_vol->node[ref_control[1]] - ref_vol->node[ref_control[0]];
	ref_control_to_control.normalise();
	control_to_control = vol->node[control[1]] - vol->node[control[0]];
	control_to_control.normalise();
	rotation_axis = vector3::cross_product(ref_control_to_control, control_to_control);
	rotation_axis.normalise();
	
	// Delete!
	rotation_axis.x = 1.0;
	rotation_axis.normalise();
		
	// Rotate about this axis until control_to_control dot ref_control_to_control = 1;
	matrix33 *rotation_matrix = new matrix33;
	float rotation_angle;
	float dot = vector3::dot_product(ref_control_to_control, control_to_control);
	rotation_angle = acos(dot);
	rotation_matrix->build_rotation_matrix(rotation_axis, rotation_angle);
	vol->rotate(rotation_matrix);
	
	// Recalculate control_to_control  
	control_to_control = vol->node[control[1]] - vol->node[control[0]];
	control_to_control.normalise();
	
	// Check rotation was correct direction
	if(vector3::dot_product(ref_control_to_control, control_to_control) > 1.01 || vector3::dot_product(ref_control_to_control, control_to_control) < 0.99) {
		rotation_angle *= -2;
		rotation_matrix->build_rotation_matrix(rotation_axis, rotation_angle);
		vol->rotate(rotation_matrix);
	}
	
	// Minimise rmsd between control nodes
	ref_control_to_control = ref_vol->node[ref_control[1]] - ref_vol->node[ref_control[0]];
	control_to_control = vol->node[control[1]] - vol->node[control[0]];
	translation.set_pos(0.0, 0.0, 0.0);
	translation = ref_vol->node[ref_control[1]] - vol->node[control[1]];
	vector3 normal = control_to_control;
	normal.normalise();
	normal *= 0.5;
	normal *= ref_control_to_control.calc_mag() - control_to_control.calc_mag();
	translation -= normal;
	printf("done!\n");
	
	// Move vol to origin
	translation.set_pos(0.0, 0.0, 0.0);
	translation -= vol->node[control[0]];
	vol->translate(translation);
	ref_vol->translate(translation);
	
	//Delete!
	normal.x= 1.0;
	normal.normalise();
	
	// Rotate around normal until ref_vol->node[ref_control[3]] - vol->node[control[3]] is minimised
	printf("Minimising total rmsd...");
	rotation_angle = M_PI;
	vector3 temp;
	temp = vol->node[control[3]] - ref_vol->node[control[3]];
	double last_distance = temp.calc_mag();
	double distance;
	rotation_matrix->build_rotation_matrix(normal, rotation_angle);
	while(true) {
		if(fabs(rotation_angle) < M_PI / 200000.0) {
			break;
		}
		vol->rotate(rotation_matrix);
		temp = vol->node[control[3]] - ref_vol->node[control[3]];
		distance = temp.calc_mag();
		if(distance > last_distance) {
			rotation_angle *= -0.5;
			rotation_matrix->build_rotation_matrix(normal, rotation_angle);
		} 
		last_distance = distance;
	}
	
	// Minimise overall rmsd between all three control nodes
	double total_rmsd, last_total_rmsd = 0.0;
	vector3 control0, control1, control2;
	control2 = ref_vol->node[ref_control[2]] - vol->node[control[2]];
	translation = control2;
	translation.normalise();
	translation *= 30 * control2.calc_mag();
	do {
		vol->translate(translation);
		control0 = ref_vol->node[ref_control[0]] - vol->node[control[0]];
		control1 = ref_vol->node[ref_control[1]] - vol->node[control[1]];
		control2 = ref_vol->node[ref_control[2]] - vol->node[control[2]];
		total_rmsd = control0.calc_mag() + control1.calc_mag() + control2.calc_mag();
		if(total_rmsd > last_total_rmsd) {
			translation *= -0.5;
		}
	} while (translation.calc_mag() > 0.0001);
	printf("done!\n");
	
	// Calculate a map!
	printf("Calculating map...");
	int **map = calc_map(vol, ref_vol, num_closest_nodes, 5.0);
	printf("done!\n");
	
	// Write to file
	printf("Writing map to file...");
	write_map_to_file(output_fname, map, vol->num_nodes, num_closest_nodes);
	printf("done!\n\nBye bye!\n");
	return 0;
}


















