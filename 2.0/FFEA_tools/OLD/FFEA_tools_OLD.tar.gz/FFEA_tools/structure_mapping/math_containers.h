#include <math.h>

class vector3 {
	
	public:
		
		vector3(double x, double y, double z) {
			this->x = x;
			this->y = y;
			this->z = z;
			calc_mag();
		}
		
		vector3() {
			this->x = 0.0;
			this->y = 0.0;
			this->z = 0.0;
			this->mag = 0.0;
		}
		
		~vector3() {
			this->x = 0.0;
			this->y = 0.0;
			this->z = 0.0;
			this->mag = 0.0;
		}
		
		// Overloaded operators
		vector3 operator+(vector3 b) {
			return vector3(x + b.x, y + b.y, z + b.z);
		}
		
		vector3 operator-(vector3 b) {
			return vector3(x - b.x, y - b.y, z - b.z);
		}
		
		vector3 operator*(double b) {
			return vector3(x * b, y * b, z * b);
		}
		
		void operator+=(vector3 b) {
			x += b.x;
			y += b.y;
			z += b.z;
		}
		
		void operator-=(vector3 b) {
			x -= b.x;
			y -= b.y;
			z -= b.z;
		}
		
		void operator*=(double b) {
			x *= b;
			y *= b;
			z *= b;
		}
		
		void set_pos(double x, double y, double z) {
			this->x = x;
			this->y = y;
			this->z = z;
		}
		
		static vector3 cross_product(vector3 a, vector3 b) {
			vector3 c;
			c.x = a.y * b.z - a.z * b.y;
			c.y = b.x * a.z - a.x * b.z;
			c.z = a.x * b.y - a.y * b.x;
			return c;
		}
		
		static double dot_product(vector3 a, vector3 b) {
			return a.x * b.x + a.y * b.y + a.z * b.z;
		}
		
		double calc_mag() {
			mag = sqrt(x * x + y * y + z * z);
			return mag;
		}
		
		void normalise() {
			calc_mag();
			if(mag == 0.0) {
				return;
			}
			x /= mag;
			y /= mag;
			z /= mag;
		}
		
		// Variables
		double x, y, z, mag;
};

class matrix33{
	
	public:
		
		matrix33() {
			el = new double*[3];
			for(int i = 0; i < 3; ++i) {
				el[i] = new double[3];
			}
		}
		
		matrix33(double xx, double xy, double xz, double yx, double yy, double yz, double zx, double zy, double zz) {
			el = new double*[3];
			for(int i = 0; i < 3; ++i) {
				el[i] = new double[3];
				if(i = 0) {
					el[i][0] = xx;
					el[i][1] = xy;
					el[i][2] = xz;
				} else if(i = 1) {
					el[i][0] = yx;
					el[i][1] = yy;
					el[i][2] = yz;
				} else {
					el[i][0] = zx;
					el[i][1] = zy;
					el[i][2] = zz;
				}
			}
		}
		
		~matrix33() {
			delete[] el;
			el = NULL;
		}
		
		void apply(vector3 *a) {
			vector3 b;
			b.x = el[0][0] * a->x + el[0][1] * a->y + el[0][2] * a->z;
			b.y = el[1][0] * a->x + el[1][1] * a->y + el[1][2] * a->z;
			b.z = el[2][0] * a->x + el[2][1] * a->y + el[2][2] * a->z;
			a->x = b.x;
			a->y = b.y;
			a->z = b.z;
		}
		
		void build_rotation_matrix(vector3 a, double angle) {
			
			// a - axis
			double c = cos(angle);
			double s = sin(angle);
			el[0][0] = c + a.x * a.x * (1 - c);
			el[0][1] = a.x * a.y * (1 - c) - a.z * s;
			el[0][2] = a.x* a.z * (1 - c) + a.y * s;
			el[1][0] = a.y * a.x * (1 - c) + a.z * s;
			el[1][1] = c + a.y * a.y * (1 - c);
			el[1][2] = a.y * a.z * (1 - c) - a.x * s;
			el[2][0] = a.z * a.x * (1 - c) - a.y * s;
			el[2][1] = a.z * a.y * (1 - c) + a.x* s;
			el[2][2] = c + a.z * a.z * (1 - c); 	
		}
		
		void print_to_screen() {
			printf("Matrix is:\n");
			for(int i = 0; i < 3; ++i) {
				for(int j = 0; j < 3; ++j) {
					printf("%e ", el[i][j]);
				}
				printf("\n");
			}
			printf("\n");
		}
	
		// Variables
			
		double **el;
};
